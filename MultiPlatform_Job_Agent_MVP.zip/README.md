# Multi-Platform Job Agent — MVP

A starter dashboard for a Hyderabad-focused job search across Internshala, Naukri, Indeed, Glassdoor, Foundit and Freshersworld.

## Filters configured
- Internships must have a clearly stated stipend greater than ₹0/month.
- Fresher/entry-level jobs.
- Roles: Python, Full Stack, AI/ML, React, Cloud/DevOps, Cybersecurity, Frontend, Backend, Data Science, Flutter and UI/UX.
- Exclude marketing, sales, business development and telecalling.
- Location: Hyderabad.

## Run
```bash
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```
Open port 8000 (also works in GitHub Codespaces).

## Current scope and limitations
This is a functional local dashboard, SQLite tracker, CSV listing importer and resume-match filter. The six portal connectors are placeholders: each portal needs an approved feed/API or individually tested, permitted browser integration. No portal is falsely represented as connected. Application submission is disabled; the app records a submission only after the user confirms it. Never bypass CAPTCHA, OTP, rate limits, access controls or portal terms.

The resume profile is seeded from Rohith Annam's uploaded resume: B.Tech CSE (2023–2027), Python, Java basics, JavaScript, SQL, React, HTML/CSS, Git/GitHub, Jenkins, Tomcat, DevOps internship, web-development internship, ABIAP and real-time music-sync chat project; FastAPI, Flutter and UI/UX are learning areas.
