import csv, io, sqlite3
from fastapi import FastAPI, UploadFile, File
from fastapi.responses import HTMLResponse

app = FastAPI(title="Multi-Platform Job Agent")
DB = "job_agent.db"
PLATFORMS = ["Internshala", "Naukri", "Indeed", "Glassdoor", "Foundit", "Freshersworld"]
ROLES = ["Python Developer", "Full Stack Developer", "AI / ML Intern", "React Developer",
         "Cloud / DevOps", "Cybersecurity", "Frontend Developer", "Backend Developer",
         "Data Science", "Flutter Developer", "UI/UX Designer"]
EXCLUDE = ["marketing", "sales", "business development", "telecalling"]

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

@app.on_event("startup")
def init():
    with db() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS jobs(
          id INTEGER PRIMARY KEY, platform TEXT, title TEXT, company TEXT, location TEXT,
          url TEXT UNIQUE, listing_type TEXT, stipend REAL, salary REAL, experience TEXT,
          description TEXT, posted TEXT, score INTEGER DEFAULT 0)""")
        c.execute("""CREATE TABLE IF NOT EXISTS applications(
          id INTEGER PRIMARY KEY, job_id INTEGER UNIQUE, status TEXT, note TEXT)""")

@app.get("/", response_class=HTMLResponse)
def home():
    return open("app/dashboard.html", encoding="utf-8").read()

@app.get("/health")
def health(): return {"ok": True}

@app.get("/api/config")
def config():
    return {"location":"Hyderabad", "platforms":PLATFORMS, "roles":ROLES,
            "stipend_rule":"stipend > ₹0; unpaid and undisclosed excluded",
            "excluded":EXCLUDE, "auto_submit":False}

def score(row):
    text = " ".join(str(row.get(k,"") or "") for k in ["title","description","experience"]).lower()
    if any(x in text for x in EXCLUDE): return 0
    if "hyderabad" not in str(row.get("location","")).lower(): return 0
    if row.get("listing_type","job").lower() == "internship":
        if row.get("stipend") is None or float(row["stipend"]) <= 0: return 0
    else:
        exp = str(row.get("experience","")).lower()
        if exp and not any(x in exp for x in ["fresher","0 year","0-1","no experience","entry level"]): return 0
    keywords = ["python","full stack","artificial intelligence","machine learning","react",
                "devops","cloud","cyber","frontend","backend","data science","flutter","ui/ux"]
    hits = sum(1 for k in keywords if k in text)
    return min(100, 25 + hits*12) if hits else 0

@app.post("/api/import/csv")
async def import_csv(file: UploadFile = File(...)):
    reader = csv.DictReader(io.StringIO((await file.read()).decode("utf-8-sig")))
    added, skipped = 0, 0
    with db() as c:
        for r in reader:
            try:
                r["stipend"] = float(r["stipend_monthly"]) if r.get("stipend_monthly") else None
                r["salary"] = float(r["salary_annual"]) if r.get("salary_annual") else None
                s = score(r)
                if not s: skipped += 1; continue
                cur = c.execute("""INSERT OR IGNORE INTO jobs
                    (platform,title,company,location,url,listing_type,stipend,salary,experience,description,posted,score)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (r.get("platform"),r.get("title"),r.get("company"),r.get("location"),r.get("url"),
                     r.get("listing_type","job"),r["stipend"],r["salary"],r.get("experience"),
                     r.get("description"),r.get("posted_on"),s))
                added += cur.rowcount
            except Exception: skipped += 1
    return {"added":added,"skipped_or_duplicate":skipped}

@app.get("/api/jobs")
def jobs():
    with db() as c: rows = c.execute("SELECT * FROM jobs ORDER BY score DESC,id DESC").fetchall()
    return [dict(x) for x in rows]

@app.get("/api/applications")
def applications():
    with db() as c:
        rows = c.execute("""SELECT a.status,a.note,j.title,j.company,j.platform,j.url
          FROM applications a JOIN jobs j ON j.id=a.job_id ORDER BY a.id DESC""").fetchall()
    return [dict(x) for x in rows]

@app.post("/api/applications/{job_id}/prepare")
def prepare(job_id:int):
    with db() as c:
        exists = c.execute("SELECT id FROM jobs WHERE id=?",(job_id,)).fetchone()
        if not exists: return {"error":"Job not found"}
        c.execute("INSERT OR IGNORE INTO applications(job_id,status,note) VALUES(?,?,?)",
                  (job_id,"ready_for_review","Use verified resume facts only; no application submitted."))
    return {"status":"ready_for_review","submitted":False}

@app.post("/api/applications/{job_id}/confirm-submitted")
def confirm_submitted(job_id:int):
    with db() as c:
        cur = c.execute("UPDATE applications SET status='submitted' WHERE job_id=?",(job_id,))
        if cur.rowcount == 0: return {"error":"Prepare this application record first"}
    return {"status":"submitted","recorded_from_user_confirmation":True}
